import org.junit.Test;

public class PresentationLayerTest {
    @Test
    public void testDisplayMenu() {

    }

    @Test
    public void testMain() {

    }
}
