import org.junit.Test;

public class CustomerTest {
    @Test
    public void testGetEmail() {

    }

    @Test
    public void testGetId() {

    }

    @Test
    public void testGetName() {

    }

    @Test
    public void testSetId() {

    }

    @Test
    public void testToString() {

    }
}
