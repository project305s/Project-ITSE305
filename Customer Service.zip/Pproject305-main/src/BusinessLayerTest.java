import org.junit.Test;

public class BusinessLayerTest {
    @Test
    public void testGetCustomerDetails() {

    }

    @Test
    public void testRegisterCustomer() {

    }
}
